from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_bcrypt import Bcrypt
import sqlite3

app = Flask(__name__)
app.secret_key = "super_secret_key"  
bcrypt = Bcrypt(app)

def init_db():
    try:
        # Database users.db (Lưu tài khoản)
        conn_users = sqlite3.connect("users.db")
        cursor_users = conn_users.cursor()
        cursor_users.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_blocked BOOLEAN NOT NULL DEFAULT 0
        )""")
        conn_users.commit()

        # Database tasks.db (Lưu công việc)
        conn_tasks = sqlite3.connect("tasks.db")
        cursor_tasks = conn_tasks.cursor()
        cursor_tasks.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            done BOOLEAN NOT NULL DEFAULT 0,
            user_id INTEGER NOT NULL
        )""")
        conn_tasks.commit()
        conn_tasks.close()
    except sqlite3.Error as e:
        print(f"Database error: {e}")

init_db()

# Kiểm tra đăng nhập
@app.route("/")
def index():
    return redirect(url_for("register"))  

# Đăng ký tài khoản mới
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if not username or not password:
            flash("Vui lòng nhập đầy đủ thông tin", "error")
            return redirect(url_for("register"))

        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        if cursor.fetchone():
            flash("Tên người dùng đã tồn tại", "error")
            conn.close()
            return redirect(url_for("register"))

        hashed_password = bcrypt.generate_password_hash(password).decode("utf-8")
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
        conn.close()

        flash("Đăng ký thành công! Vui lòng đăng nhập.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

# Đăng nhập
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user_type = request.form["user_type"]  

        # Admin cố định
        if username == "Admin" and password == "Admin":
            session["user_id"] = "admin_fixed"  
            flash("Đăng nhập Admin thành công!", "success")
            return redirect(url_for("admin"))

        # Xử lý đăng nhập User thông thường từ database
        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute("SELECT id, password, is_blocked FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()

        if user:
            if user[2]:  
                flash("Tài khoản của bạn đã bị khóa.", "error")
                return redirect(url_for("login"))

            if bcrypt.check_password_hash(user[1], password):
                session["user_id"] = user[0]  
                flash("Đăng nhập thành công!", "success")
                return redirect(url_for("todolist"))

        flash("Sai tài khoản hoặc mật khẩu!", "error")
    return render_template("login.html")

# Trang Todo List
@app.route("/todolist")
def todolist():
    if "user_id" not in session:
        return redirect(url_for("login"))  

    conn = sqlite3.connect("tasks.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, text, done FROM tasks WHERE user_id = ?", (session["user_id"],))
    tasks = [{"id": row[0], "text": row[1], "done": row[2]} for row in cursor.fetchall()]
    conn.close()
    return render_template("index.html", tasks=tasks)

# Đăng xuất
@app.route("/logout")
def logout():
    session.pop("user_id", None)
    flash("Đã đăng xuất thành công!", "success")
    return redirect(url_for("login"))

# Thêm công việc mới
@app.route("/add", methods=["POST"])
def add_task():
    if "user_id" not in session:
        return redirect(url_for("login"))
    
    task_text = request.form["task"].strip()
    
    if not task_text:
        flash("Nội dung công việc không thể để trống!", "error")
        return redirect(url_for("todolist"))

    conn = sqlite3.connect("tasks.db")  
    cursor = conn.cursor()
    
    
    cursor.execute("SELECT id FROM tasks WHERE text = ? AND user_id = ?", (task_text, session["user_id"]))
    existing_task = cursor.fetchone()

    if existing_task:
        flash("Công việc này đã tồn tại!", "error")
    else:
        cursor.execute("INSERT INTO tasks (text, user_id) VALUES (?, ?)", (task_text, session["user_id"]))
        conn.commit()
        flash("Thêm công việc thành công!", "success")

    conn.close()
    return redirect(url_for("todolist"))

# Xóa công việc
@app.route("/delete/<int:task_id>")
def delete_task(task_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect("tasks.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tasks WHERE id = ? AND user_id = ?", (task_id, session["user_id"]))
    conn.commit()
    conn.close()
    flash("Đã xóa công việc!", "success")
    return redirect(url_for("todolist"))

# Kiểm tra hoàn thành
@app.route("/done/<int:task_id>")
def toggle_task(task_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect("tasks.db")
    cursor = conn.cursor()
    cursor.execute("SELECT done FROM tasks WHERE id = ? AND user_id = ?", (task_id, session["user_id"]))
    task = cursor.fetchone()
    if task:
        new_status = 1 - task[0]
        cursor.execute("UPDATE tasks SET done = ? WHERE id = ?", (new_status, task_id))
        conn.commit()
        flash("Cập nhật trạng thái công việc!", "success")
    conn.close()
    return redirect(url_for("todolist"))

# Trang quản lý người dùng cho admin
@app.route("/admin")
def admin():
    if "user_id" not in session:
        return redirect(url_for("login")) 

    # Kiểm tra nếu là Admin cố định
    if session["user_id"] == "admin_fixed":
        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, is_blocked FROM users")
        users = cursor.fetchall()
        conn.close()
        return render_template("admin.html", users=users)

    flash("Bạn không có quyền truy cập trang Admin!", "error")
    return redirect(url_for("todolist"))

# Khóa người dùng
@app.route("/block_user/<int:user_id>")
def block_user(user_id):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_blocked = 1 WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()
    flash("Đã khóa người dùng!", "success")
    return redirect(url_for("admin"))


@app.route('/unblock_user/<int:user_id>')
def unblock_user(user_id):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_blocked = 0 WHERE id = ?", (user_id,))

    conn.commit()
    conn.close()
    return redirect(url_for('admin'))

# Reset mật khẩu
@app.route("/reset_password/<int:user_id>", methods=["POST"])
def reset_password(user_id):
    new_password = request.form["new_password"]
    hashed_password = bcrypt.generate_password_hash(new_password).decode("utf-8")

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET password = ? WHERE id = ?", (hashed_password, user_id))
    conn.commit()
    conn.close()
    flash("Đã reset mật khẩu thành công!", "success")
    return redirect(url_for("admin"))

if __name__ == "__main__":
    app.run(debug=True)